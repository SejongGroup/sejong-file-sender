/**
 * 
 */
package com.sejong.cdbiz.except;

/**
 * @FileName	: SessionTimeOutException.java
 * @Project		: cdBiz
 * @Date		: 2021. 5. 17.
 * @Author		: JH.KIM
 * @Description : 
 * ==========================================================
 * DATE				AUTHOR				NOTE
 * ==========================================================
 *
 */
public class SessionTimeOutException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
