/**
 * 
 */
package com.sejong.cdbiz.except;

/**
 * @FileName	: RegularExpressException.java
 * @Project		: cdBiz
 * @Date		: 2021. 5. 17.
 * @Author		: JH.KIM
 * @Description : 
 * ==========================================================
 * DATE				AUTHOR				NOTE
 * ==========================================================
 *
 */
public class RegularExpressException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
